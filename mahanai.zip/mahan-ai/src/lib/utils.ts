export function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function formatFaNumber(value: number) {
  return new Intl.NumberFormat("fa-IR").format(value);
}
