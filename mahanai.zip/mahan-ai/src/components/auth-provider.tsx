"use client";
import { ClerkProvider } from "@clerk/nextjs";
import type { ReactNode } from "react";

export default function AuthProvider({ children }: { children: ReactNode }) {
  const key = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;
  if (!key) return children;
  return <ClerkProvider publishableKey={key}>{children}</ClerkProvider>;
}
