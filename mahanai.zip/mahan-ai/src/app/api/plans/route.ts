export const dynamic = "force-dynamic";
export async function GET() {
  return Response.json({ plans: [
    { id: "free", name: "رایگان", price_irr: 0, daily_message_limit: 30 },
    { id: "plus", name: "Plus", price_irr: 0, daily_message_limit: 100 },
    { id: "pro", name: "Pro", price_irr: 0, daily_message_limit: 300 }
  ] }, { headers: { "Cache-Control": "no-store" } });
}
